const form = document.getElementById('questionForm');
const input = document.getElementById('questionInput');
const messages = document.getElementById('messages');
const chatView = document.getElementById('chatView');
const tipsView = document.getElementById('tipsView');
const pageTitle = document.getElementById('pageTitle');

const knowledgeBase = [
  {keys:['photosynthesis','plant food','chlorophyll'], title:'Photosynthesis', answer:'Photosynthesis is the process by which green plants make their own food. They use sunlight, water from the soil and carbon dioxide from the air to make glucose (a type of sugar). Oxygen is released during this process.\n\nRemember it as: sunlight + water + carbon dioxide → glucose + oxygen.', tip:'Try drawing a leaf and labelling the sunlight, water, carbon dioxide and oxygen arrows.'},
  {keys:['water cycle','rain','evaporation','condensation'], title:'The water cycle', answer:'The water cycle is the continuous movement of water between Earth’s surface and the atmosphere.\n\n1. Evaporation: the Sun heats water and it changes into water vapour.\n2. Condensation: water vapour cools and forms tiny droplets in clouds.\n3. Precipitation: water falls as rain, snow or hail.\n4. Collection: water gathers in rivers, lakes and oceans, and the cycle continues.', tip:'Remember the order: evaporation → condensation → precipitation → collection.'},
  {keys:['fraction','fractions','numerator','denominator'], title:'Fractions', answer:'A fraction represents a part of a whole. It has two parts: the numerator (top number), which tells how many parts we have, and the denominator (bottom number), which tells how many equal parts make the whole.\n\nFor example, 3/4 means 3 out of 4 equal parts.', tip:'Draw a rectangle, divide it into four equal boxes and shade three boxes to picture 3/4.'},
  {keys:['gravity','gravitation'], title:'Gravity', answer:'Gravity is a force of attraction between objects that have mass. Earth’s gravity pulls objects towards its centre, which is why things fall towards the ground when dropped. Gravity also helps keep the Moon in orbit around Earth and planets in orbit around the Sun.', tip:'Think about what happens when you gently drop a pencil. Gravity pulls it towards the floor.'},
  {keys:['cell','cells','biology'], title:'Cells', answer:'A cell is the basic structural and functional unit of living organisms. Some organisms consist of one cell, while plants and animals are made of many cells. Common cell parts include the cell membrane, cytoplasm and genetic material. Plant cells also have a cell wall and usually a large central vacuole.', tip:'Make a labelled diagram of a plant cell and an animal cell, then compare their parts.'},
  {keys:['photosynthesis equation','chemical equation'], title:'A simple science equation', answer:'For photosynthesis, plants use carbon dioxide and water in the presence of light energy to produce glucose and oxygen. The balanced chemical equation is: 6CO₂ + 6H₂O → C₆H₁₂O₆ + 6O₂ (in the presence of light).', tip:'Learn what each formula represents before memorising the equation.'},
  {keys:['study','revision','exam','concentrate','focus'], title:'Study planning', answer:'A useful study routine is to choose one clear goal, study it in a focused session, take a short break and then test your understanding without looking at your notes. Return to the topic later for another quick review.', tip:'Write down the one topic you want to understand today and the small task you will complete.'}
];

function getResponse(question) {
  const q = question.toLowerCase();
  const match = knowledgeBase.find(item => item.keys.some(key => q.includes(key)));
  if (match) return `Here is a simple explanation of ${match.title}:\n\n${match.answer}\n\nStudy tip: ${match.tip}`;
  return `Good question! I can help you get started.\n\nTry breaking “${question}” into smaller parts:\n1. Write down what you already know about the topic.\n2. Identify the exact word, step or idea that is confusing.\n3. Look for a definition and one everyday example.\n4. Explain the idea in your own words.\n\nStudy tip: Try asking a more specific question, such as “Explain [topic] in simple words” or “Give me an example of [topic]”.\n\nThis prototype currently has prepared learning guides for photosynthesis, the water cycle, fractions, gravity, cells and study planning.`;
}

function addMessage(text, who) {
  const empty = messages.querySelector('.empty-state');
  if (empty) empty.remove();
  const row = document.createElement('div');
  row.className = `message ${who}`;
  if (who === 'bot') {
    const icon = document.createElement('div'); icon.className = 'mini-avatar'; icon.textContent = '✦'; row.appendChild(icon);
  }
  const bubble = document.createElement('div'); bubble.className = 'bubble'; bubble.textContent = text; row.appendChild(bubble);
  messages.appendChild(row); messages.scrollTop = messages.scrollHeight;
}

function ask(question) {
  const clean = question.trim(); if (!clean) return;
  addMessage(clean, 'user');
  addMessage(getResponse(clean), 'bot');
  input.value = '';
}
form.addEventListener('submit', event => { event.preventDefault(); ask(input.value); });
document.querySelectorAll('.prompt-card').forEach(button => button.addEventListener('click', () => ask(button.dataset.prompt)));
document.getElementById('clearBtn').addEventListener('click', () => { messages.innerHTML = '<div class="empty-state"><div class="empty-icon">✧</div><strong>Your conversation will appear here</strong><p>Try one of the suggested topics or type your own question below.</p></div>'; });
document.getElementById('tipsNav').addEventListener('click', () => { chatView.classList.add('hidden'); tipsView.classList.remove('hidden'); pageTitle.textContent = 'Study tips'; document.getElementById('tipsNav').classList.add('active'); document.getElementById('chatNav').classList.remove('active'); });
document.getElementById('chatNav').addEventListener('click', () => { tipsView.classList.add('hidden'); chatView.classList.remove('hidden'); pageTitle.textContent = 'Your learning space'; document.getElementById('chatNav').classList.add('active'); document.getElementById('tipsNav').classList.remove('active'); });
