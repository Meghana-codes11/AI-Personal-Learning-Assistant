# LearnMate – AI-Powered Personal Learning Assistant

**Student:** Meghana Sara Niju  
**SDG:** United Nations Sustainable Development Goal 4 – Quality Education

## Project overview
LearnMate is a responsive educational assistant prototype. Students can ask questions, explore prepared explanations for selected school topics, and view practical study tips.

## Features
- Responsive learning dashboard
- Interactive question-and-answer interface
- Built-in topic guide for photosynthesis, the water cycle, fractions, gravity, cells and study planning
- Suggested questions and clear-chat control
- Separate study tips page
- No installation or account required

## Run the project
1. Download or clone this repository.
2. Open `index.html` in a modern web browser.
3. Choose a suggested question or type your own question and press **Send**.
4. Select **Study tips** in the left navigation to view learning suggestions.

## Technology stack
- HTML5 – page structure
- CSS3 – responsive styling and layout
- JavaScript – interaction and local topic-matching response logic
- GitHub – source-code hosting

## Important implementation note
This submission is a working front-end prototype. It does not currently call a hosted generative-AI model. The response engine matches questions against a small built-in topic guide and provides prepared explanations or general study guidance. A future version can connect a secure backend to a generative AI API. API keys should never be placed in browser-side JavaScript.

## Project files
- `index.html` – application structure
- `styles.css` – visual design and responsive layout
- `script.js` – question handling and response engine
- `screenshots/` – prototype screenshots
- `SDG4_AI_Personal_Learning_Assistant_Report.pdf` – project report

## SDG connection
The project supports SDG 4 by demonstrating a simple way technology can make learning resources more accessible and encourage independent learning. It is a student prototype, not a replacement for teachers or verified learning materials.
